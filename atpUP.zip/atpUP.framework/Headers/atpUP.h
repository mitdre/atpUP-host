#import <Foundation/Foundation.h>

@class AUPAtpPresenter, AUPStdlibByteArray, AUPStdlibByteIterator;

@protocol AUPIAtpPresenter, AUPIAtpView, AUPOnInputListener, AUPIAtpManager, AUPIStringEncoder, AUPITicketSerializer, AUPStdlibIterator;

NS_ASSUME_NONNULL_BEGIN

@interface KotlinBase : NSObject
-(instancetype) init __attribute__((unavailable));
+(instancetype) new __attribute__((unavailable));
+(void)initialize __attribute__((objc_requires_super));
@end;

@protocol AUPIAtpPresenter
@required
-(void)setViewView:(id<AUPIAtpView>)view NS_SWIFT_NAME(setView(view:));
-(void)setupIsBroadcaster:(BOOL)isBroadcaster NS_SWIFT_NAME(setup(isBroadcaster:));
-(BOOL)sendOutput:(NSString*)output NS_SWIFT_NAME(send(output:));
-(void)pause NS_SWIFT_NAME(pause());
-(void)resume NS_SWIFT_NAME(resume());
-(void)close NS_SWIFT_NAME(close());
@end;

@protocol AUPOnInputListener
@required
-(void)onConnected NS_SWIFT_NAME(onConnected());
-(void)onInputBytes:(AUPStdlibByteArray*)bytes NS_SWIFT_NAME(onInput(bytes:));
@end;

__attribute__((objc_subclassing_restricted))
@interface AUPAtpPresenter : KotlinBase <AUPIAtpPresenter, AUPOnInputListener>
-(instancetype)initWithManager:(id<AUPIAtpManager>)manager encoder:(id<AUPIStringEncoder>)encoder serializer:(id<AUPITicketSerializer>)serializer NS_SWIFT_NAME(init(manager:encoder:serializer:)) NS_DESIGNATED_INITIALIZER;

@property (readonly) id<AUPIAtpManager> manager;
@property (readonly) id<AUPIStringEncoder> encoder;
@property (readonly) id<AUPITicketSerializer> serializer;
@end;

@protocol AUPIAtpManager
@required
-(void)setupIsBroadcaster:(BOOL)isBroadcaster NS_SWIFT_NAME(setup(isBroadcaster:));
-(BOOL)sendBytes:(AUPStdlibByteArray*)bytes NS_SWIFT_NAME(send(bytes:));
-(BOOL)listenListener:(id<AUPOnInputListener>)listener NS_SWIFT_NAME(listen(listener:));
-(void)pause NS_SWIFT_NAME(pause());
-(void)resume NS_SWIFT_NAME(resume());
-(void)close NS_SWIFT_NAME(close());
@end;

@protocol AUPIAtpView
@required
-(void)displayTicketTicketJson:(NSString*)ticketJson NS_SWIFT_NAME(displayTicket(ticketJson:));
-(void)displayInputInputString:(NSString*)inputString NS_SWIFT_NAME(displayInput(inputString:));
@end;

@protocol AUPIStringEncoder
@required
-(NSString*)encodeToString:(AUPStdlibByteArray*)toString NS_SWIFT_NAME(encode(toString:));
-(AUPStdlibByteArray*)decodeToBytes:(NSString*)toBytes NS_SWIFT_NAME(decode(toBytes:));
@end;

@protocol AUPITicketSerializer
@required
-(BOOL)isTicketJson:(NSString*)json NS_SWIFT_NAME(isTicket(json:));
@end;

__attribute__((objc_subclassing_restricted))
@interface AUPStdlibByteArray : KotlinBase
+(instancetype)arrayWithSize:(int32_t)size NS_SWIFT_NAME(init(size:));

+(instancetype)arrayWithSize:(int32_t)size init:(NSNumber*(^)(NSNumber*))init NS_SWIFT_NAME(init(size:init:));

+(instancetype)alloc __attribute__((unavailable));
+(instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));

-(int8_t)getIndex:(int32_t)index NS_SWIFT_NAME(get(index:));
-(AUPStdlibByteIterator*)iterator NS_SWIFT_NAME(iterator());
-(void)setIndex:(int32_t)index value:(int8_t)value NS_SWIFT_NAME(set(index:value:));
@property (readonly) int32_t size;
@end;

@protocol AUPStdlibIterator
@required
-(BOOL)hasNext NS_SWIFT_NAME(hasNext());
-(id _Nullable)next NS_SWIFT_NAME(next());
@end;

@interface AUPStdlibByteIterator : KotlinBase <AUPStdlibIterator>
-(instancetype)init NS_SWIFT_NAME(init()) NS_DESIGNATED_INITIALIZER;

-(NSNumber*)next NS_SWIFT_NAME(next());
-(int8_t)nextByte NS_SWIFT_NAME(nextByte());
@end;

NS_ASSUME_NONNULL_END
